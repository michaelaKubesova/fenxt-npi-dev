
select
 "PostStatusId",
 "PostStatus"
from dm_PostStatus
where TenantId = '${TenantId}'
